#!/bin/bash
dc kill
dc up -d
dc logs
